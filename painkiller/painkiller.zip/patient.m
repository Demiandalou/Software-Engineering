classdef patient < handle
    properties
        Name
        weight
    end
    
    methods
        
    end
    
end