classdef physician < handle
    properties
        Name
        password
    end
    
    methods
        
    end
    
end